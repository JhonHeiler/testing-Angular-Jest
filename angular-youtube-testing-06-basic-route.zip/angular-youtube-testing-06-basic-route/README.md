# AngularTesting - Con Jest

* [Pasos para configurar Jest en Angular](https://gist.github.com/Klerith/ca4573d13844f53af3ff68846a238fc3)

